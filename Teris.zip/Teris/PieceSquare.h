#pragma once
#include "Piece.h"
class PieceSquare : public Piece
{
public:
	PieceSquare();
};

