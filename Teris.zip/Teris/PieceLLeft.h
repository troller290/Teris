#pragma once
#include "Piece.h"
class PieceLLeft : public Piece
{
public:
	PieceLLeft();
};

