#pragma once
#include "Piece.h"
class PieceI : public Piece
{
public:
	PieceI();
};

