#include "PieceSquare.h"

PieceSquare::PieceSquare()
{
	shape =
	{
		{
			{'X', 'X', '.', '.'},
			{'X', 'X', '.', '.'},
			{'.', '.', '.', '.'},
			{'.', '.', '.', '.'}
		}
	};
}