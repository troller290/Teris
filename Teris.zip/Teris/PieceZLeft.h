#pragma once
#include "Piece.h"
class PieceZLeft : public Piece
{
public:
	PieceZLeft();
};

