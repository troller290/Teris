#include "Game.h"

int main()
{
	Game Tetris;
	Tetris.start_game();
	return 0;
}