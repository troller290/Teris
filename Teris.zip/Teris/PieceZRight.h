#pragma once
#include "Piece.h"
class PieceZRight : public Piece
{
public:
	PieceZRight();
};

