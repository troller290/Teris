#pragma once
#include "Piece.h"
class PieceT : public Piece
{
public:
	PieceT();
};

