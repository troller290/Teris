#pragma once
#include "Piece.h"
class PieceLRight : public Piece
{
public:
	PieceLRight();
};

